<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\ContractController;
use App\Http\Controllers\Api\PaymentController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|


*/
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('/auth/register', [UserController::class, 'createUser']);

Route::get('/payments/{contract_no}', [PaymentController::class, 'findPaymentByContract']);

Route::post('/payments', [PaymentController::class, 'addPayment']);

Route::post('/auth/login', [UserController::class, 'loginUser']);

//Route::get('customer', [CustomerController::class, 'index']);

//Route::get('customers', [CustomerController::class, 'index']);


Route::group([
    "middleware" => ["auth:sanctum"]
], function(){
    Route::get("profile", [UserController::class, 'profile']);

    Route::post("contract", [ContractController::class, 'addContract']);

    Route::get("logout", [UserController::class, 'logoutUser']);

    Route::post('customers', [CustomerController::class, 'store']);

    Route::put('customers/{id}/editContracts', [CustomerController::class, 'updateCustomerContracts']);

    Route::get('customers', [CustomerController::class, 'index']);

    Route::get('customers/{id}/edit', [CustomerController::class, 'findCustomer']);

    Route::put('customers/{id}/edit', [CustomerController::class, 'updateCustomer']);

    Route::get('customers/{nic}', [CustomerController::class, 'searchCustomer']);

    Route::get('contracts', [ContractController::class, 'index']);

    Route::post('contracts/add', [ContractController::class, 'addContract']);

    Route::get('contracts/{id}/edit', [ContractController::class, 'editContract']);

    Route::put('contracts/{id}/edit', [ContractController::class, 'updateContract']);

    Route::get('contracts/{contract_no}', [ContractController::class, 'findContract']);
});

